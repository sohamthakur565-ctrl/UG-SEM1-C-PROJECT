#include <iostream>
using namespace std;
int main()
{
    int num1, num2;
    cout << "Enter the number 1 : ";
    cin >> num1;
    cout << "Enter the number 2 : ";
    cin >> num2;

    int sum = num1 + num2;
    cout << "\nSum of both number is : " << sum;

    return 0;

}

/*
<< is called Insertion operator
>> is called Extraction operator
*/