#include<iostream>
using namespace std;

int c = 89;

int main()
{
    int a,b,c;
    cout<<"Enter a : ";
    cin>>a;
    cout<<"Enter b : ";
    cin>>b;

    c = a+b;

    cout<<"Sum = "<<c<<endl;

    cout<<"Global c is : "<<::c<<endl;// Use :: for print or use the global value of any variable
    cout<<"local c is : "<<c<<endl;

    return 0;
}


/*
If we store a decimal value in float and double variable then the computer take the floating value as double by default

to solve this use l, and f with the value for make computer understand it

x = 45.6F/f;
y = 45.6l/L;
*/


/*
The n comes to typecasting 

it is method to change the datatype from one to other

int to float
float to int
*/