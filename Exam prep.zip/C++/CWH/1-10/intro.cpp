#include <iostream>
using namespace std;

int main()
{
    cout<<"Hello World\n";

    int a = 5;
    char b = 'a';

    cout<<"The value of a is "<<a<<".\nThe character stored in b is '"<<b<<"'.";
    
    return 0;
}