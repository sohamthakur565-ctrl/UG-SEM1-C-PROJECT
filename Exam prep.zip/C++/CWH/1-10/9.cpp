#include <iostream>
using namespace std;

int main()
{
    int age;
    cout << "Tell me your age : ";
    cin >> age;

    // if (age < 18)
    // {
    //     printf("You can't vote"); // cout<<"You can't vote"<<endl;
    // }
    // else if (age == 18)
    // {
    //     printf("You can't vote"); // cout<<"You can't vote"<<endl;
    // }
    // else
    // {
    //     printf("You can vote"); // cout<<"You can vote"<<endl;
    // }

    switch (age)
    {
    case 18:
        cout << "you can vote" << endl;
        break;
    case 20:
        cout << "you can't vote" << endl;
        break;
    case 95:
        cout << "Then ready to die" << endl;
        break;

    default:
        break;
    }

    return 0;
}

/*
If you comment out the break statements then all the statements will print after the correct statements
*/