#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

    int a = 5, b = 56, c = 4562;

    cout << "Value of a without setw is : " << a << endl;
    cout << "Value of b without setw is : " << b << endl;
    cout << "Value of c without setw is : " << c << endl;

    cout << endl;
    cout << "Value of b with setw is : " << setw(3) << a << endl;
    cout << "Value of a with setw is : " << setw(3) << b << endl;
    cout << "Value of c with setw is : " << setw(7) << c << endl;

    return 0;
}

/*
By using const(constant) you can't change their value
if you try to do it the compiler give you error
*/

// setw(n) : This will print the number using spaces of n numbers and starting from the right side
// This function come with header file "iomanip"