#include <iostream>
using namespace std;

int main()
{
    int num;
    cout << "Enter number : ";
    cin >> num;
    // for (int i = 1; i <= num; i++)
    // {
    //     cout << i << endl;
    // }

    int i = 1;

    // while (i <= num)
    // {
    //     cout << i<< endl;
    //     i++;
    // }

    do
    {
        cout << num << " X " << i << " = " << num * i << endl;
        i++;
    } while (i < 11);

    return 0;
}