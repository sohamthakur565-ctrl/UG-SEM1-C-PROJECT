#include <iostream>

//#include<thisfile> -->  By doing this you can include any file in your code which presents in this directory

// Use endl for new line


using namespace std;

int main()
{

    // cout<<"Hello world"<<endl<<"Tata bye bye";

    

    return 0;
}
