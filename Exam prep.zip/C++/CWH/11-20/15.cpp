#include <iostream>
using namespace std;

int sum(int num1, int num2);

int main()
{

    int num1, num2;
    std::cout << "Enter number 1 : ";
    cin >> num1;
    std::cout << "Enter number 2 : ";
    cin >> num2;
    std::cout << "The sum is " << sum(num1, num2);

    return 0;
}

int sum(int num1, int num2)
{
    int c = num1 + num2;
    return c;
}