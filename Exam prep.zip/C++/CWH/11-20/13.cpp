#include <iostream>
// #include<stdio.h>        C style header
// #include<cstdio>     C++ style header
using namespace std;

int main()
{

    int num;
    cout << "Enter the size of array : ";
    cin >> num;

    int arr[num];

    cout << "Enter " << num << " elements : ";
    for (int i = 0; i < num; i++)
    {
        cin >> arr[i];
    }

    cout << "The elements you entered is : ";
    for (int i = 0; i < num; i++)
    {
        cout << arr[i] << " ";
    }

    int *a = arr;

    cout << endl;
    cout << endl;
    for (int i = 0; i < num; i++)
    {
        cout << *a << " ";
        a++;
    }

    return 0;
}

/*
Use any of header file from those two to use printf function or c language function
*/

/*
pointer arithmetic formula : address(new) = address(current) + i*sizeof(datatype)
*/