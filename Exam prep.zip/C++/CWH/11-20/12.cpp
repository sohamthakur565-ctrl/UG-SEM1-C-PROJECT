#include <iostream>
using namespace std;

int main()
{
    int a = 3;
    int *ptr = &a;

    cout << "The address of a is " << &a << endl;
    cout << "The value stored in ptr is " << ptr << endl;
    cout << "The value stored in a is " << a << endl;
    cout << "The address of ptr is " << &ptr << endl;
    cout << "The value which ptr is pointing towards is " << *ptr << endl;

    int **b = &ptr;
    cout << endl;
    cout << "The address of b is " << &b << endl;
    cout << "The value stored in b is " << b << endl;
    cout << "The value which b is pointing towards is " << **b << endl;
    cout << "The address of ptr is " << &ptr << endl;
    cout << "The value stored in ptr is " << ptr << endl;

    return 0;
}