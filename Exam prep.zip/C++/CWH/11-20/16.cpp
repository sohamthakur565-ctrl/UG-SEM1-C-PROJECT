#include <iostream>
using namespace std;

// void swap(int a, int b);

void swap_pointer(int *a, int *b);

int main()
{

    int a, b;
    cout << "Enter the value of a : ";
    cin >> a;
    cout << "Enter the value of b : ";
    cin >> b;

    // swap(a, b);

    swap_pointer(&a, &b);
    cout << "After swap value of a : " << a << endl;
    cout << "After swap value of b : " << b << endl;

    return 0;
}

// void swap(int a, int b)
// {
//     int temp = a;
//     a = b;
//     b = temp;

//     cout << "After swap value of a : " << a << endl;
//     cout << "After swap value of b : " << b << endl;
// }

void swap_pointer(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}