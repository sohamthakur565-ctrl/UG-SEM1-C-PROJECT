#include <iostream>
using namespace std;

struct lappu
{
    int Lid;
    char favchar;
    float salary;
};

enum meal
{
    breakfast,
    lunch,
    dinner
};

int main()
{

    enum meal now = lunch;

    if (now == lunch)
    {
        cout << "Now is lunch";
    }

    // struct lappu one;
    // one.Lid = 12;
    // one.favchar = 'b';
    // one.salary = 125063;

    // cout << "The value is " << one.Lid << endl;
    // cout << "The value is " << one.favchar << endl;
    // cout << "The value is " << one.salary << endl;

    return 0;
}

/*

Use of typedef

typedef struct employee
{
}EP;

we can write "EP name" instead of "Struct employee name"

*/

/*

Union : All members use the same memory (memory of union = memory of largest member)
        Because they all share the same memory so writing to the one it will overwrites the other
        also we cannot use the multiple memebers at same time

*/

/*

Enum : We store the value in enum. It deafulty start from 0, improves the code readability, prevent invalid values and easy to maintain

*/