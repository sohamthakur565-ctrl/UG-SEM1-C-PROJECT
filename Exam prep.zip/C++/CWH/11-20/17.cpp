#include <iostream>
using namespace std;

// int product(int a, int b);

int money_receive(int salary, float interest = 1.04)
{
    return salary * interest;
}

int main()
{
    // int a, b;
    // cout << "Enter the value of a : ";
    // cin >> a;
    // cout << "Enter the value of b : ";
    // cin >> b;

    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;
    // cout << "The sum after product of both digit is " << product(a, b) << endl;

    int salary = 100000;

    cout << "The money you will get after the 1 year is " << money_receive(salary) << endl;
    cout << "For VIP's money they will get after the 1 year is " << money_receive(salary, 10) << endl;

    return 0;
}

// int product(int a, int b)
// {
//     static int c = 0; // This will execute only one time
//     c = c + 1; // After everytime we recall the function, it will retained it last value and add 1 in it

//     return a * b + c;
// }

/*
You can see the value already given in the function is called default argument. when we does not give the value to function it will automatically consider it the default value
*/