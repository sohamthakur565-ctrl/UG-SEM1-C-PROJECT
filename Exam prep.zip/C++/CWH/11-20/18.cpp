#include <iostream>
using namespace std;

void hello(int n)
{
    cout << "Hello world no. " << n << endl;
    n = n - 1;
    if (n > 0)
    {
        hello(n);
    }
}

int main()
{

    int num;
    cout << "Enter any number : ";
    cin >> num;

    hello(num);
 
    return 0;
}