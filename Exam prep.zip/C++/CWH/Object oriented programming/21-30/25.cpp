#include <iostream>
using namespace std;

class employee
{
    int id;
    double salary;

public:
    void setid(void)
    {
        salary = 25, 000;
        cout << "Enter id : ";
        cin >> id;
    }
    void getid(void)
    {
        cout << "The Id of employee is " << id << " and the salary is " << salary << endl;
    }
};

int main()
{
    employee fb[4];

    for (int i = 0; i < 4; i++)
    {
        fb[i].setid();
    }
    for (int i = 0; i < 4; i++)
    {
        fb[i].getid();
    }

    return 0;
}