#include <iostream>
using namespace std;

class employee
{
    int id;
    static int count;

public:
    void setdata(void)
    {
        cout << "Id : ";
        cin >> id;
        count++;
    }
    void getdata(void)
    {
        cout << "Id : " << id << " and this is employee number " << count << endl;
    }
};

int employee ::count;

int main()
{
    employee harry, rohan, lovish;

    harry.setdata();
    harry.getdata();
    cout << endl;

    rohan.getdata();
    rohan.setdata();
    cout << endl;

    lovish.setdata();
    lovish.getdata();

    return 0;
}