#include <iostream>
using namespace std;

class shop
{
    int itemid[100];
    int itemprice[100];
    int count;

public:
    void initcounter(void) { count = 0; }
    void getprice(void);
    void displayprice(void);
};

void shop ::getprice(void)
{
    cout << "Enter Id of item : ";
    cin >> itemid[count];
    cout << "Enter price of item : ";
    cin >> itemprice[count];
    count++;
}

void shop ::displayprice(void)
{
    for (int i = 0; i < count; i++)
    {
        cout << "The price of item with Id " << itemid[i] << " is " << itemprice[i] << endl;
    }
}

int main()
{
    shop dukaan;

    dukaan.initcounter();

    dukaan.getprice();
    dukaan.getprice();
    dukaan.getprice();
    dukaan.getprice();

    dukaan.displayprice();

    return 0;
}