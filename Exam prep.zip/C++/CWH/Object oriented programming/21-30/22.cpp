#include <iostream>
using namespace std;

// Class -> Extension of structures(in C)
class binary
{
    string s;

public:
    void read(void);
    void chk_bin(void);
};

void binary ::read(void)
{
    cout << "Enter binary number : ";
    cin >> s;
}
void binary ::chk_bin(void)
{
    for (int i = 0; i < s.length(); i++)
    {
        if (s.at(i) != '0' && s.at(i) != '1')
        {
            cout << "Incorrect binary format" << endl;
            exit(0);
        }
    }
}

int main()
{
    binary c1;
    c1.read();
    c1.chk_bin();

    return 0;
}