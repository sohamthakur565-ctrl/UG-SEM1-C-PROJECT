#include <iostream>
#include <string>

using namespace std;

class Person
{
private:
    string name;
    int age;
    string country;

public:
    void setName(string n)
    {
        name = n;
    }

    void setAge(int a)
    {
        if (a >= 0)
        {
            age = a;
        }
        else
        {
            cout << "Invalid age!" << endl;
        }
    }

    void setCountry(string c)
    {
        country = c;
    }

    string getName()
    {
        return name;
    }

    int getAge()
    {
        return age;
    }

    string getCountry()
    {
        return country;
    }
};

int main()
{
    Person p1;

    p1.setName("Alice");
    p1.setAge(25);
    p1.setCountry("USA");

    cout << "Person Details:" << endl;
    cout << "Name: " << p1.getName() << endl;
    cout << "Age: " << p1.getAge() << endl;
    cout << "Country: " << p1.getCountry() << endl;

    return 0;
}