#include <iostream>
#include <string>
using namespace std;

class Vehicle
{
public:
    void start_transport()
    {
        cout << "Vehicle transport started. Moving..." << endl;
    }
};

// Derived Class 1
class Car : public Vehicle
{
private:
    int number_of_doors;

public:
    void setDoors(int doors)
    {
        number_of_doors = doors;
    }

    void open_door()
    {
        cout << "Opening one of the " << number_of_doors << " doors." << endl;
    }
};

// Derived Class 2
class SportsCar : public Car
{
private:
    int max_speed;

public:
    void setMaxSpeed(int speed)
    {
        max_speed = speed;
    }

    void activate_turbo()
    {
        cout << "Turbo activated! Reaching speeds up to " << max_speed << " mph!" << endl;
    }
};

int main()
{

    SportsCar myFerrari;

    myFerrari.start_transport();

    myFerrari.setDoors(2);
    myFerrari.open_door();

    myFerrari.setMaxSpeed(220);
    myFerrari.activate_turbo();

    return 0;
}