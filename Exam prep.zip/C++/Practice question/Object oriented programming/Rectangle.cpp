// #include <iostream>
// using namespace std;

// class rectangle
// {
//     int length;
//     int breadth;

// public:
//     int perimeter;
//     int area;

//     void set(void)
//     {
//         cout << "Enter length : ";
//         cin >> length;
//         cout << "Enter breadth : ";
//         cin >> breadth;
//     }
//     void get(void)
//     {
//         perimeter = 2 * (length + breadth);
//         area = length * breadth;
//         cout << "Perimeter : " << perimeter << " and Area : " << area << endl;
//     }
// };

// int main()
// {

//     rectangle r1, r2;

//     r1.set();
//     r1.get();

//     r2.set();
//     r2.get();

//     return 0;
// }

#include <iostream>
using namespace std;

class Rectangle
{
private:
    double length;
    double width;

public:
    Rectangle(double l = 0, double w = 0)
    {
        length = l;
        width = w;
    }

    void setDimensions(double l, double w)
    {
        length = l;
        width = w;
    }

    double calculateArea()
    {
        return length * width;
    }

    double calculatePerimeter()
    {
        return 2 * (length + width);
    }
};

int main()
{
    Rectangle r1;
    double l, w;

    cout << "Enter length and width for Rectangle 1: ";
    cin >> l >> w;

    r1.setDimensions(l, w);

    cout << "Area: " << r1.calculateArea() << endl;
    cout << "Perimeter: " << r1.calculatePerimeter() << endl;

    return 0;
}