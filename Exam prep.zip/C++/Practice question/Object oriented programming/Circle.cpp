// #include <iostream>
// using namespace std;

// class circle
// {
//     int radius;

// public:
//     float perimeter;
//     float area;

//     int peri_area(int r)
//     {
//         perimeter = 2 * 3.14 * r;
//         area = 3.14 * r * r;

//         return perimeter, area;
//     }

//     void get(void)
//     {
//         cout << "Perimeter : " << perimeter << " and Area : " << area << endl;
//     }
// };

// int main()
// {

//     circle c1;
//     c1.peri_area(100);
//     c1.get();

//     return 0;
// }

#include <iostream>
#include <cmath>

using namespace std;

class Circle
{
private:
    double radius;

public:
    Circle(double r)
    {
        radius = r;
    }

    double calculateArea()
    {
        return 3.14159 * radius * radius;
    }

    double calculateCircumference()
    {
        return 2 * 3.14159 * radius;
    }
};

int main()
{
    double r;
    cout << "Enter radius: ";
    cin >> r;

    Circle c1(r);

    cout << "Area: " << c1.calculateArea() << endl;
    cout << "Circumference: " << c1.calculateCircumference() << endl;

    return 0;
}