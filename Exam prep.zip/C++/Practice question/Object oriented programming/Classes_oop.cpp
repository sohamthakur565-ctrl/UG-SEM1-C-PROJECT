#include <iostream>
using namespace std;
class Teacher
{
private:
    double salary;

public:
    string name;
    string dept;
    string subject;

    // void changedept(string newdept)
    // {
    //     dept = newdept;
    // }
    Teacher(string name, string dept, string subject, double salary)
    {
        this->name = name;
        this->dept = dept;
        this->subject = subject;
        this->salary = salary;
    }
    Teacher(Teacher &orgobj)
    {
        cout << "Hey! This is custom copy constructor" << endl;
        this->name = orgobj.name;
        this->dept = orgobj.dept;
        this->subject = orgobj.subject;
        this->salary = orgobj.salary;
    }
    // void setsal(double s)
    // {
    //     salary = s;
    // }
    // double getsal()
    // {
    //     return salary;
    // }
    void getinfo()
    {
        cout << "Name : " << name << endl;
        cout << "Subject : " << subject << endl;
    }
};

int main()
{
    Teacher t1("Jatt", "CSE Core", "C++", 25300);
    Teacher t2(t1);
    t2.getinfo();

    return 0;
}