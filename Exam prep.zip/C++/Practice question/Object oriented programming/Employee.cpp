// #include <iostream>
// #include <string>

// using namespace std;

// // Base Class
// class Employee {
// protected: // 'protected' allows derived classes to access these variables
//     string name;
//     int id;
//     double salary;

// public:
//     void setData() {
//         cout << "Enter Name: ";
//         cin >> name;
//         cout << "Enter ID: ";
//         cin >> id;
//         cout << "Enter Base Salary: ";
//         cin >> salary;
//     }
// };

// // Derived Class 1
// class Manager : public Employee {
// public:
//     void displayInfo() {
//         // Managers get a 5000 bonus
//         cout << "Manager: " << name << " | ID: " << id 
//              << " | Final Salary: " << salary + 5000 << endl;
//     }
// };

// // Derived Class 2
// class Engineer : public Employee {
// public:
//     void displayInfo() {
//         // Engineers get a 10000 bonus
//         cout << "Engineer: " << name << " | ID: " << id 
//              << " | Final Salary: " << salary + 10000 << endl;
//     }
// };

// int main() {
//     Manager m1;
//     cout << "--- Enter Manager Details ---" << endl;
//     m1.setData();
    
//     Engineer e1;
//     cout << "\n--- Enter Engineer Details ---" << endl;
//     e1.setData();

//     cout << "\n--- Payroll Summary ---" << endl;
//     m1.displayInfo();
//     e1.displayInfo();

//     return 0;
// }




#include <iostream>
#include <string>

using namespace std;

// Base Class
class Employee {
protected:
    string name;
    int id;
    double baseSalary;

public:
    Employee(string n, int i, double s) : name(n), id(i), baseSalary(s) {}

    // Virtual function to be overridden
    virtual void displaySalary() {
        cout << "Employee: " << name << " | Total Salary: $" << baseSalary << endl;
    }
};

// Derived Class: Manager
class Manager : public Employee {
private:
    double bonus;

public:
    Manager(string n, int i, double s, double b) : Employee(n, i, s), bonus(b) {}

    // Overriding the base class function
    void displaySalary() override {
        double total = baseSalary + bonus;
        cout << "Manager: " << name << " | Base: $" << baseSalary 
             << " | Bonus: $" << bonus << " | Total: $" << total << endl;
    }
};

// Derived Class: Engineer
class Engineer : public Employee {
private:
    double overtimePay;

public:
    Engineer(string n, int i, double s, double ot) : Employee(n, i, s), overtimePay(ot) {}

    // Overriding the base class function
    void displaySalary() override {
        double total = baseSalary + overtimePay;
        cout << "Engineer: " << name << " | Base: $" << baseSalary 
             << " | Overtime: $" << overtimePay << " | Total: $" << total << endl;
    }
};

int main() {
    // Creating objects of derived classes
    Manager m1("Sarah", 101, 5000, 1500);
    Engineer e1("Alex", 102, 4000, 800);

    cout << "--- Salary Details ---" << endl;
    
    // Each object calls its own version of displaySalary()
    m1.displaySalary();
    e1.displaySalary();

    return 0;
}