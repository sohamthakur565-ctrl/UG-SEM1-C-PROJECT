// #include <iostream>
// using namespace std;

// class bankaccount
// {
// private:
//     long int acc_num;
//     double balance;
//     int temp;

// public:
//     int deposit;
//     int withdraw;

//     void getinfo(void)
//     {
//         cout << "Enter account number : ";
//         cin >> acc_num;
//         cout << "Enter balance : ";
//         cin >> balance;
//     }

//     double getdeposit(double d)
//     {
//         deposit = d;
//         balance = balance + deposit;
//         return balance;
//     }
//     double getwithdraw(double w)
//     {
//         withdraw = w;
//         if (w <= 0)
//         {
//             cout << "Please enter some amount !!";
//         }
//         else
//         {
//             if (withdraw <= balance)
//             {
//                 balance = balance - withdraw;
//                 return balance;
//             }
//             else
//             {
//                 cout << "Insufficient balance ";
//             }
//         }
//     }
// };

// int main()
// {

//     bankaccount b1;
//     b1.getinfo();

//     cout << "Bank balance after deposit of 500 is " << b1.getwithdraw(2500) << endl;

//     return 0;
// }

#include <iostream>
using namespace std;

class BankAccount
{
private:
    long int acc_num;
    double balance;

public:
    void setAccountInfo(long int number, double initial_balance)
    {
        acc_num = number;
        balance = (initial_balance >= 0) ? initial_balance : 0;
    }

    void deposit(double amount)
    {
        if (amount > 0)
        {
            balance += amount;
            cout << "Successfully deposited: $" << amount << endl;
        }
        else
        {
            cout << "Invalid deposit amount!" << endl;
        }
    }

    void withdraw(double amount)
    {
        if (amount <= 0)
        {
            cout << "Please enter a positive amount to withdraw." << endl;
        }
        else
        {
            if (amount > balance)
            {
                cout << "Insufficient funds! Withdrawal denied." << endl;
            }
            else
            {
                balance -= amount;
                cout << "Successfully withdrew: $" << amount << endl;
            }
        }
    }

    double getBalance()
    {
        return balance;
    }
};

int main()
{
    BankAccount b1;
    b1.setAccountInfo(123456789, 1000.0);

    cout << "Initial Balance: $" << b1.getBalance() << endl;

    b1.deposit(500.0);
    cout << "Balance after deposit: $" << b1.getBalance() << endl;

    b1.withdraw(2000.0);
    b1.withdraw(300.0);

    cout << "Final Balance: $" << b1.getBalance() << endl;

    return 0;
}