#include <iostream>
using namespace std;
class student
{
public:
    string name;
    double *cgpaptr;

    student(string name, double cgpa)
    {
        this->name = name;
        cgpaptr = new double;
        *cgpaptr = cgpa;
    }
    student(student &obj)
    {
        this->name = obj.name;
        this->cgpaptr = obj.cgpaptr;
    }
    void getinfo()
    {
        cout << "Name : " << name << endl;
        cout << "CGPA : " << *cgpaptr << endl;
    }
};

int main()
{
    student st1("Jatin", 8.9);
    st1.getinfo();

    // student st2(st1);
    // st2.getinfo();

    return 0;
}