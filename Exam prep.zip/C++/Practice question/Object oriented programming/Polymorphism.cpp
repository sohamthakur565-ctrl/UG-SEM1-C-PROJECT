#include <iostream>
using namespace std;
class parent
{
public:
    void getinfo()
    {
        cout << "Parent class" << endl;
    }
    virtual void hello()
    {
        cout << "Hey! I am the parent" << endl;
    }
};
class child
{
public:
    void hello()
    {
        cout << "Hey! I am the child" << endl;
    }
};

int main()
{
    parent p1;
    child c1;

    p1.hello();
    c1.hello();

    return 0;
}