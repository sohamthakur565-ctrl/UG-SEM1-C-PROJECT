#include <iostream>
#include <cmath>

using namespace std;


class Shape {
public:

    virtual double calculate_area() = 0;


    virtual ~Shape() {} 
};

// Derived Class: Circle
class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}

    double calculate_area() override {
        return 3.14159 * radius * radius;
    }
};

// Derived Class: Rectangle
class Rectangle : public Shape {
private:
    double width, height;
public:
    Rectangle(double w, double h) : width(w), height(h) {}

    double calculate_area() override {
        return width * height;
    }
};

int main() {
    
    Shape* shapePtr;

    Circle myCircle(5.0);
    Rectangle myRect(4.0, 6.0);

    // Pointing to Circle
    shapePtr = &myCircle;
    cout << "Area of Circle: " << shapePtr->calculate_area() << endl;

    // Pointing to Rectangle
    shapePtr = &myRect;
    cout << "Area of Rectangle: " << shapePtr->calculate_area() << endl;

    return 0;
}