#include <iostream>
using namespace std;
class person
{
public:
    string name;
    int age;

    person(string name, int age)
    {
        this->name = name;
        this->age = age;
    }
    
};

class student : public person
{
public:
    int rollno;

    student(string name, int age, int rollno) : person(name, age)
    {
        this->rollno = rollno;
    }

    void getinfo()
    {
        cout << "Name : " << name << endl;
        cout << "Age : " << age << endl;
        cout << "Roll no : " << rollno << endl;
    }
    
};

int main()
{
    // person P1("Jatin", 19);
    student st1("Jatin", 20, 123);

    st1.getinfo();
    return 0;
}