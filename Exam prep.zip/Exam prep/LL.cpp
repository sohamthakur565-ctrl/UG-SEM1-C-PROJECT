#include <iostream>
using namespace std;

class PatientQueue
{
    struct Node
    {
        int pID;
        Node *next;
    };
    Node *head;

    bool isEmpty()
    {
        return head == nullptr;
    }

public:
    PatientQueue()
    {
        head = nullptr;
    }

    void EmgPat(int id)
    {
        Node *newNode = new Node{id, head};
        head = newNode;
        cout << "Emergency Patient admitted" << endl;
    }

    void RegPat(int id)
    {
        Node *newNode = new Node{id, nullptr};
        if (isEmpty())
        {
            head = newNode;
            return;
        }
        Node *temp = head;
        while (temp->next != nullptr)
        {
            temp = temp->next;
        }
        temp->next = newNode;
        cout << "Regular patient admitted" << endl;
    }

    void add_at(int id, int pos)
    {
        if (pos <= 1)
        {
            EmgPat(id);
            return;
        }
        Node *temp = head;
        for (int i = 0; i < pos-1 && temp != nullptr; i++)
        {
            temp = temp->next;
        }
        if (temp == nullptr)
        {
            cout << "Invalid position" << endl;
            return;
        }
        Node *newNode = new Node{id, temp->next};
        temp->next = newNode;
        cout << "Patient admitted" << endl;
    }

    void die_first()
    {
        if (isEmpty())
        {
            cout << "Empty" << endl;
            return;
        }
        Node *temp = head;
        head = head->next;
        delete temp;
        cout << "Patient died" << endl;
    }

    void die_last()
    {
        if (isEmpty())
        {
            cout << "Empty" << endl;
            return;
        }
        if (head->next == nullptr)
        {
            delete head;
            head = nullptr;
            return;
        }
        Node *temp = head;
        while (temp->next->next != nullptr)
        {
            temp = temp->next;
        }
        delete temp->next;
        temp->next = nullptr;
    }

    void search(int id)
    {
        if (isEmpty())
        {
            cout << "Empty" << endl;
            return;
        }
        int pos = 0;
        Node *temp = head;
        while (temp != nullptr)
        {
            if (temp->pID == id)
            {
                cout << "Patient founded at " << pos + 1 << endl;
            }
            temp = temp->next;
            pos++;
        }
    }
};