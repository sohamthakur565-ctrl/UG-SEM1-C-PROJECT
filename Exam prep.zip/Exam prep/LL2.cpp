#include <iostream>
using namespace std;

class patientQueue
{
    struct Node
    {
        int pID;
        Node *next;
    };
    Node *head;

    bool isEmpty()
    {
        return head == nullptr;
    }

public:
    void add_first(int id)
    {
        if (isEmpty())
        {
            cout << "Empty" << endl;
            return;
        }
        Node *newNode = new Node{id, head};
        head = newNode;
        cout << "Patient added" << endl;
    }

    void add_last(int id)
    {
        Node *newNode = new Node{id, nullptr};
        if (isEmpty())
        {
            cout << "Empty" << endl;
            return;
        }
        Node *temp = head;
        while (temp->next != nullptr)
        {
            temp = temp->next;
        }
        temp->next = newNode;
        cout << "Patient admitted" << endl;
    }

    void add_at(int id, int pos)
    {
        if (isEmpty())
        {
            cout << "Empty" << endl;
        }
        if (pos < 1)
        {
            add_first(id);
            return;
        }
        Node *temp = head;
        for (int i = 0; i < pos - 1 && temp != nullptr; i++)
        {
            temp = temp->next;
        }
        if (temp == nullptr)
        {
            cout << "Invalid position" << endl;
            return;
        }

        Node *newNode = new Node{id, temp->next};
        temp->next = newNode;
        cout << "Patient admitted" << endl;
    }

    void first_die()
    {
        Node* temp = head;
        head = head->next;
        delete temp;
        cout<<"Deleted"<<endl;
    }
};

int main()
{

    return 0;
}