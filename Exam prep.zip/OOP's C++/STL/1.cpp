#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

class student
{
public:
    int id;
    string name;
    double marks;


    void input()
    {
        cout << "Enter student id : ";
        cin >> id;
        cout << "Enter student name : ";
        cin >> name;
        cout << "Enter student marks : ";
        cin >> marks;
    }

    void display()
    {
        cout<<"Id : "<<id<<endl;
        cout<<"Name : "<<name<<endl;
        cout<<"Marks : "<<marks<<endl;
    }

    
};

void addstudent()
    {
        student s;
        ofstream FILE("Student.txt", ios::app);
        s.input();
        FILE.write((char *)&s, sizeof(s));
        FILE.close();
        cout<<"Student record entered"<<endl;
    }

void viewstudent()
{
    student s;
    ifstream FILE("student.txt", ios::app);
    while(FILE.read((char*)&s, sizeof(s))){
    s.display();
    }
    FILE.close();

}

void dhundoo()
{
    int found = 0;
    int id;
    cout<<"Enter student id to found : ";
    cin>>id;
    student s;
    ifstream FILE("student.txt");
    while(FILE.read((char*)&s, sizeof(s)));
    if(s.id == id)
    {
        s.display();
        found = 1;
        return;
    }
    FILE.close();
    if(found == 0)
    {
        cout<<"No student found"<<endl;
        return;
    }
}

int main()
{
    int ch;
    cout<<"Student management system"<<endl;
    cout<<"1. Add student record"<<endl;
    cout<<"2. View students record"<<endl;
    cout<<"3. Find student"<<endl;
    cout<<"Enter task option to perform : ";
    cin>>ch;
    switch (ch)
    {
    case 1:
        addstudent();
        break;
    case 2:
        viewstudent();
        break;
    case 3:
        dhundoo();
        break;
    
    default:
        break;
    }
}